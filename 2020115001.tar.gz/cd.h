#ifndef __CHNG_DIR_H_
#define __CHNG_DIR_H_

void call_CD(char *path);

#endif
