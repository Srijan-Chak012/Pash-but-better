#ifndef __PIPE_N_REDIRECT_H_
#define __PIPE_N_REDIRECT_H_

char* getFileName(int, int*, char*);
int isPipeOrRedirect(char*);

#endif