#ifndef __ECHO_CMD_H_
#define __ECHO_CMD_H_

void call_echo(char *str);

#endif
