#ifndef __PW_DIR_H
#define __PW_DIR_H

void present_working_directory();

#endif
