#ifndef __FG_BG_H_
#define __FG_BG_H_

void fgbg (char*);
void _foreground(int);
void _background(int);

#endif
