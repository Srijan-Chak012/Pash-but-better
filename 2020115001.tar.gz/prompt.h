#ifndef __PROMPT_H_
#define __PROMPT_H_

#define RED "\033[01;91m"
#define MAGENTA "\033[01;35m"
#define brightBLUE "\033[00;94m"
#define WHITE "\033[00;37m"
#define RESET "\033[00m"

void prompt();

#endif
