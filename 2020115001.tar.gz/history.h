#ifndef __HIST_H_
#define __HIST_H_

void initialize_history();
void append_history(char * command);
void history(int n);

#endif