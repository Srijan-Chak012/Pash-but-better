#ifndef __DISCOVER_H_
#define __DISCOVER_H_

void discover(char **commands, int num);

#endif
