#ifndef __CMND_H_
#define __CMND_H_

void call_command(char*, bool);
void execute(char*);

#endif