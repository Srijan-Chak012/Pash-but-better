#ifndef __PINFO_H
#define __PINFO_H

void pinfo(char *str, char *num);

#endif